//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"
for i in 1...10 {
    i * i
}
