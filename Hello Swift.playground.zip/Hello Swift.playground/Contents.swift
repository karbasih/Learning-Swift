//: Playground - noun: a place where people can play

//: _Single Line_ rich text *comment* using __Markdown__ syntax

import UIKit

var str = "Hello, playground"

var mySet : Set<String> = ["myValue", "myValue2"]

